## Preparar el entorno

Ante todo, debemos tener instalado NODE JS.

```sh
git clone https://github.com/dnmartel/Coder-NodeJS.git
npm install

Variable Administrador se setea de forma manual, archivo server.js, linea 7, por defecto en TRUE.
```

## Producción

```sh
Ver en Glitch.com
```

## Desarrollo (nodemon)

```sh
npm run dev
```
